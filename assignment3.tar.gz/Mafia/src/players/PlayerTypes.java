package players;

public class PlayerTypes {
	
	public enum PlayerType {INNO, MAFIA};

}
